<?php 
	
	$messages = array(
		'errorDeleteDepartment' => 'Não é possível excluir este departamento pois possui usuário(s) vinculado à ele',
		'validEmail' => 'Entre com um e-mail válido',
		'requiredEmail' => 'O e-mail é obrigatório',
	);

?>