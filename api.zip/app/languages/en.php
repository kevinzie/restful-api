<?php 
	
	$messages = array(
		'errorDeleteDepartment' => 'Department cannot be deleted bacause it\'s used on User',
		'validEmail' => 'Type a valid e-mail',
		'requiredEmail' => 'The e-mail is required',
	);

?>