<?php

class ErrorController extends \Phalcon\Mvc\Controller
{

	/**
	 * Error 404 (page not found)
	 * @return html page error
	 */
    public function page404Action()
    {

    }

}

