<?php

class MasterobatController extends RestController
{

}

