<?php

class DepartmentController extends RestController
{

}

