<?php

class UserController extends RestController
{

}

