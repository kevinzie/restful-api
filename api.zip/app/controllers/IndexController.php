<?php

class IndexController extends RestController
{

    public function indexAction()
    {
		
    }

}

