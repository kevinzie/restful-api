This folder is used for Phalcon Dev Tools to recognized a phalcon framework project
